--------------------------------------
PCB: 600-60527-01 Rev: 03 
--------------------------------------

PCB Name: CY8CPROTO-063-BLE PSoC 6 BLE PROT0 KIT 

PCB P/N: 600-60527-01 

PCB Rev.: 03 


---------------------------------
----------- PCB Info ------------
---------------------------------

PCB Size: 4.025" x 1.052" 

Layer Count: 2 

Minimum O/L Line Width: 5.010 
Minimum O/L Spacing:    4.990 

Minimum I/L Line Width: N/A 
Minimum I/L Spacing:    N/A 

BGA PIN Pitch: No Devices found. 

Non-BGA Pin Pitch MM (Minimum): 0.400 (Mils: 15.740) 
Non-BGA Reference Designator: U1 / Pins: 63-62 / Pin Count: 71 
Non-BGA Location: (284.7 400.0) - Top Side 

Silkscreen Layers: 2 



---------------------------------
---------- Drill Info -----------
---------------------------------

Number of Different Hole Sizes: 7 

Smallest Hole Size: 0.008 

Largest Hole Size: 0.040 

Hole Count: 433 

Blind-Buried Vias: No 

Slots Found: Yes 


---------------------------------
---------- Extra Info -----------
---------------------------------

